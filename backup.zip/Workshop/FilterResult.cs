﻿namespace Workshop
{
    public class FilterResult
    {
        public WorkshopItem[] Items { get; set; }
        public int MaxPages { get; set; }
    }
}
