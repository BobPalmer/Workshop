﻿using System.Collections.Generic;

namespace Workshop
{
    public class OseModuleCategoryAddon : PartModule
    {
        [KSPField]
        public PartCategories Category;

        [KSPField]
        public string IconPath;
    }
}
