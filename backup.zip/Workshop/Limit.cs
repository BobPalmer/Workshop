﻿namespace Workshop
{
    public class Limit
    {
        public string Technology;

        public float MaxVolume;
    }
}
